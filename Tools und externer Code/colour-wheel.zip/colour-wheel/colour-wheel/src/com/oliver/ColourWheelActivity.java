/* Colour Wheel Demo
 * Demo of the colour wheel widget
 * Copyright (C) 2011  Oliver Thearle
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *
 *http://code.google.com/p/colour-wheel/
 */
 package com.oliver;

import android.app.Activity;
import android.os.Bundle;
import android.widget.SeekBar;

import com.oliver.ColourWheel.OnColourWheelChangeListener;

public class ColourWheelActivity extends Activity {
    /** Called when the activity is first created. */
	SeekBar seekbar;
	
	ColourWheel seekbar2;
	
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        seekbar2 = (ColourWheel) findViewById(R.id.seekBar1);
        //seekbar = (SeekBar) findViewById(R.id.seekBar1);
        seekbar2.setOnColourWheelChangeListener(RGBLISTENER);
    }
    
    static final OnColourWheelChangeListener RGBLISTENER = new OnColourWheelChangeListener () {

		@Override
		public void onColourChanged(ColourWheel colourWheel, int red, int green, int blue) {
			
		}

		@Override
		public void onStartTrackingTouch(ColourWheel colourWheel) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStopTrackingTouch(ColourWheel colourWheel) {
			// TODO Auto-generated method stub
			
		}
    	
    };
}